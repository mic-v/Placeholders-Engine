#version 330 core
out vec4 fragColour;

void main()
{
	fragColour = vec4(1.0);
}