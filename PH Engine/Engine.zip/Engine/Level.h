#pragma once

class Level
{
public:
private:
};
