#pragma once

/*
	ResourceManager class using singleton pattern
	There is only one instance of this class and mostly all of its
	functions are static

*/

class ResourceManager
{
public:



private:

	//
	ResourceManager() {}
}